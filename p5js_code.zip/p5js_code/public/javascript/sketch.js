let overAllTexture;
let size = 600;
let shape;
let rot;
let vp;
let vpz;
const LATITUDE_BANDS = 10;
const LONGITUDE_BANDS = 10;

// Socket.io connection
const socket = io();

// Create connection to Node.JS Server
socket.on("connect", () => {
  console.log("Connected:", socket.id);
});

socket.on("message", (message) => {
  if (message.address === "/mpu6050/gyro") {
    // Update rotation based on gyro data
    rot.x = message.args[1] * 0.001; // pitch
    rot.y = message.args[0] * 0.001; // roll
    rot.z = message.args[2] * 0.001; // yaw
  }
});

function setupGraphic() {
  overAllTexture = createGraphics(width, height);
  overAllTexture.loadPixels();
  let d = pixelDensity();
  for (let i = 0; i < width * d; i++) {
    for (let o = 0; o < height * d; o++) {
      overAllTexture.set(
        i,
        o,
        color(0, noise(i / 10, o / 10, (i * o) / 1000) * random([0, 10, 20]))
      );
    }
  }
  overAllTexture.updatePixels();
}

function updateGraphic() {
  push();
  blendMode(BLEND);
  image(overAllTexture, 0, 0);
  pop();
}

class Shape {
  constructor() {
    this.vert = [];
    this.edge = {};
  }

  addVert(x, y, z) {
    this.vert.push(createVector(x, y, z));
    this.edge[this.vert.length - 1] = [];
  }

  rotateOnY(a) {
    let _v = createVector(0, 0);
    for (let i = 0; i < this.vert.length; i++) {
      _v.x = this.vert[i].x;
      _v.y = this.vert[i].z;
      _v.rotate(a);
      this.vert[i].x = _v.x;
      this.vert[i].z = _v.y;
    }
  }

  rotateOnX(a) {
    let _v = createVector(0, 0);
    for (let i = 0; i < this.vert.length; i++) {
      _v.x = this.vert[i].y;
      _v.y = this.vert[i].z;
      _v.rotate(a);
      this.vert[i].y = _v.x;
      this.vert[i].z = _v.y;
    }
  }

  rotateOnZ(a) {
    let _v = createVector(0, 0);
    for (let i = 0; i < this.vert.length; i++) {
      _v.x = this.vert[i].x;
      _v.y = this.vert[i].y;
      _v.rotate(a);
      this.vert[i].x = _v.x;
      this.vert[i].y = _v.y;
    }
  }

  getVert(i) {
    if (i >= this.vert.length) {
      console.log("vertex doesn't exist");
      return;
    }
    return this.vert[i];
  }

  getVertN() {
    return this.vert.length;
  }
}

function setup() {
  createCanvas(size, size);
  setupGraphic();
  
  rot = createVector(0, 0, 0);
  vp = createVector(0, 0);
  vpz = -500;
  
  // Initialize shape
  shape = new Shape();
  
  // Generate sphere vertices
  const radius = 50;
  for (let lat = 0; lat <= LATITUDE_BANDS; lat++) {
    const theta = (lat * Math.PI) / LATITUDE_BANDS;
    const sinTheta = Math.sin(theta);
    const cosTheta = Math.cos(theta);

    for (let long = 0; long <= LONGITUDE_BANDS; long++) {
      const phi = (long * 2 * Math.PI) / LONGITUDE_BANDS;
      const x = radius * Math.cos(phi) * sinTheta;
      const y = radius * cosTheta;
      const z = radius * Math.sin(phi) * sinTheta;
      
      shape.addVert(x, y, z);
    }
  }
}

function persp(vect3) {
  let k = 1;
  let x = vect3.x + ((vect3.x - vp.x) / (vect3.z - vpz)) * -vpz * k;
  let y = vect3.y + ((vect3.y - vp.y) / (vect3.z - vpz)) * -vpz * k;
  return createVector(x, y);
}

function draw() {
  background(10, 20);
  translate(width / 2, height / 2);

  // Apply rotations from sensor data
  shape.rotateOnY(rot.x);
  shape.rotateOnX(rot.y);
  shape.rotateOnZ(rot.z);

  // Draw vertices and effects
  fill(255, 20);
  for (let i = 0; i < shape.getVertN(); i++) {
    const vt = shape.getVert(i);
    const pv = persp(vt);
    const r = persp(createVector(10, 10, vt.z / 2));
    
    // Draw main points
    ellipse(pv.x/2, pv.y/2, dist(r.x, r.y, 0, 0)/10+2);
    ellipse(pv.x*2, pv.y*2, dist(r.x, r.y, 0, 0)/10+2);
    
    // Draw connecting lines
    stroke(75, 123, 253, 3);
    strokeWeight(20);
    line(pv.x/5, pv.y/5, 0, 0);
    line(pv.x*2, pv.y*2, pv.x*1.8, pv.y*1.8);
    
    // Draw detail lines
    push();
    strokeWeight(1);
    stroke(255, 255);
    line(pv.x/5, pv.y/5, 0, 0);
    line(pv.x*1.5, pv.y*1.5, pv.x*1.6, pv.y*1.6);
    pop();
  }

  // Update background texture
  translate(-width / 2, -height / 2);
  updateGraphic();
}

function mouseWheel(event) {
  vpz = min(vpz - max(min(event.delta, 30), -30), -100);
}

// Handle window resize
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  setupGraphic();
}

function keyPressed() {
  if (key === 'f' || key === 'F') {
    // 切换全屏模式
    let fs = fullscreen();
    fullscreen(!fs);
  }

}